'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('grouptabs', 'type', {
      type: Sequelize.STRING,
      allowNull: false,
      defaultValue: 'group',  // default type is 'group', broadcast will be 'broadcast'
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('grouptabs', 'type');
  }
};
